import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [loading, setLoading] = useState(false);
  const [cryptoData, setCryptoData] = useState(null);
  const [aiResponse, setAiResponse] = useState("");

  const getRecommendation = async () => {
    setLoading(true);
    const res = await fetch("/api/recommend");
    const data = await res.json();
    setCryptoData(data.marketData);
    setAiResponse(data.advice);
    setLoading(false);
  };

  return (
    <main className="p-10 max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold mb-4">Crypto Oracle</h1>
      <p className="mb-6 text-gray-600">
        Get intelligent Buy/Hold/Sell signals for BTC & ETH.
      </p>
      <Button onClick={getRecommendation} disabled={loading}>
        {loading ? "Analyzing..." : "Get Market Advice"}
      </Button>

      {aiResponse && (
        <div className="mt-8 bg-white shadow-xl rounded-2xl p-6 space-y-4">
          <h2 className="text-xl font-semibold">AI Recommendation</h2>
          <pre className="text-sm whitespace-pre-wrap">{aiResponse}</pre>
        </div>
      )}
    </main>
  );
}
