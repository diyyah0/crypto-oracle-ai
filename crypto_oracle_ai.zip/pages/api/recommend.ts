import type { NextApiRequest, NextApiResponse } from "next";
import OpenAI from "openai";

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

async function getMarketData() {
  const res = await fetch(
    "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum&vs_currencies=usd&include_24hr_change=true"
  );
  const json = await res.json();
  return json;
}

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const marketData = await getMarketData();

  const prompt = `
You are Crypto Oracle, a financial AI that analyzes live crypto data to give Buy, Hold, or Sell recommendations.

Market Data:
BTC: $${marketData.bitcoin.usd} (24h: ${marketData.bitcoin.usd_24h_change.toFixed(2)}%)
ETH: $${marketData.ethereum.usd} (24h: ${marketData.ethereum.usd_24h_change.toFixed(2)}%)

Based on price momentum, short-term volatility, and likely retail sentiment, give:
- An action (Buy, Hold, or Sell) for each
- Confidence Score
- Risk Level
- Technical Reasoning
- 1-day, 7-day, and 30-day forecast

Use a professional, concise tone.
`;

  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [{ role: "user", content: prompt }],
    temperature: 0.7,
  });

  const advice = completion.choices[0].message.content;

  res.status(200).json({ marketData, advice });
}
